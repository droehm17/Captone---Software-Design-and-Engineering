package com.zybooks.project2_inventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Database extends SQLiteOpenHelper {

    public static final String Customer_userName = "CUSTOMER_USERNAME";

    public Database(@Nullable Context context) {
        super(context, "customer.db", null, 1);
    }

    private static final class CustomerTable {
        private static final String Table = "customer";
        private static final String COL_ID = "_id";
        private static final String COL_Username = "Username";
        private static final String COL_Password = "Password";

    }

    //Called first time accessing database object (generate new table)
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(("create table " + CustomerTable.Table + " (" +
                CustomerTable.COL_ID + " integer primary key autoincrement, " +
                CustomerTable.COL_Username + " text, " +
                CustomerTable.COL_Password + " text) "));

    }

    // Whenever a new version is called
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {

        db.execSQL("drop table if exists " + CustomerTable.Table);
        onCreate(db);
    }

}

//  public boolean addOne(CreateAccount customerModel){
//      SQLiteDatabase db = this.getWritableDatabase();
//     ContentValues cv = new ContentValues();

//      cv.put(Customer_userName,CreateAccount.getusername());
//50.50 https://www.youtube.com/watch?v=312RhjfetP8



