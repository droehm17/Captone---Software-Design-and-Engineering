package com.zybooks.project2_inventoryapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class send_sms extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitysendsms);
}}
