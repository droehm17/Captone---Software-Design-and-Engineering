package com.zybooks.project2_inventoryapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class ListDataActivity extends AppCompatActivity {
    private static final String TAG = "ListDataActivity";
    InventoryDatabase inventoryDatabase;
    private ListView listView;

    private ToDoList ToDoList;
    private EditText ItemEditText;
    private TextView ItemListTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view_layout);


            ItemEditText = findViewById(R.id.toDoItem);
            ItemListTextView = findViewById(R.id.itemList);

            ToDoList = new ToDoList(this);
        }

        @Override
        protected void onResume() {
            super.onResume();

            try {
                // Attempt to load a previously saved list
                ToDoList.readFromFile();
                displayList();
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        @Override
        protected void onPause() {
            super.onPause();

            try {
                // Save list for later
                ToDoList.saveToFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        public void addButtonClick(View view) {

            // Ignore any leading or trailing spaces
            String item = ItemEditText.getText().toString().trim();

            // Clear the EditText so it's ready for another item
            ItemEditText.setText("");

            // Add the item to the list and display it
            if (item.length() > 0) {
                ToDoList.addItem(item);
                displayList();
                Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_SHORT).show();
            }
        }

        private void displayList() {

            // Display a numbered list of items
            StringBuffer itemText = new StringBuffer();
            String[] items = ToDoList.getItems();
            for (int i = 0; i < items.length; i++) {
                itemText.append((i + 1) + ". " + items[i] + "\n");
            }

            ItemListTextView.setText(itemText);
        }

        public void clearButtonClick(View view) {
            ToDoList.clear();
            displayList();
        }









       // listView = (ListView) findViewById(R.id.listView);
    //    inventoryDatabase = new InventoryDatabase(this);
   //    // populatelistView();

  //  }

   // private void populatelistView(){
  //  Log.d(TAG, "populateListView: Displaying data in the ListView.");
  //  Cursor data = inventoryDatabase.getData();
  //  ArrayList<String> listData = new ArrayList<>();
   // while(data.moveToNext()){
    //    listData.add(data.getString(1));
   // }
    //    ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
   // //listView.setAdapter(adapter);
   // }
//private void toastMessage(String message){
    //Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
}

