package com.zybooks.project2_inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Homescreen extends AppCompatActivity {

    //private static final String TAG = "Homescreen";
    //InventoryDatabase InventoryDatabase;
   // private Button btnAdd,btnViewData;
    //private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);
     //   editText = (EditText) findViewById(R.id.editTextInventory);
    //    btnAdd = (Button) findViewById(R.id.buttonAddItem);
     //   btnViewData = (Button) findViewById(R.id.buttonViewData);
     //   InventoryDatabase = new InventoryDatabase(this);


   /// btnAdd.setOnClickListener(new View.OnClickListener(){
     //   @Override
       //         public void onClick(View v){
       //     String newEntry = editText.getText().toString();
        //    if (editText.length() != 0) {
        //        AddData(newEntry);
         //       editText.setText("");
        //    }else{
         //       Toast.makeText(Homescreen.this, "Field cannot be blank", Toast.LENGTH_SHORT).show();
         //   }
         //   }
       // });
  //  btnViewData.setOnClickListener(new View.OnClickListener() {
  //  @Override
    //    public void onClick(View v){
    //    Intent intent = new Intent(Homescreen.this,ListDataActivity.class);
     //   startActivity(intent);
  //  }
  //  });

  //  }

  //  public void AddData(String newEntry){
   // boolean InsertData = InventoryDatabase.addData(newEntry);
   // if (InsertData) {
   //     Toast.makeText(Homescreen.this, "Data successfully inserted", Toast.LENGTH_SHORT).show();
   // }else{
   //     Toast.makeText(Homescreen.this, "Something went wrong", Toast.LENGTH_SHORT).show();
   // }
    }


   // private void toastMessage(String message){
     //   Toast.makeText(this."Inserted",Toast.LENGTH_SHORT).show();
    //}
}