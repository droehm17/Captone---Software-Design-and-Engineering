import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

//public class Dialog extends DialogFragment {

    //Dialog button
  //  @Override
 //   public Dialog onCreateDialog(Bundle savedInstanceState) {
   //     return new AlertDialog.Builder(getActivity())
   //             .setTitle(R.string.inventory_notification)
   //             .setMessage(R.string.inventory_notification_text)
   //             .A(R.string.yes, new DialogInterface.OnClickListener() {
   //                 public void onClick(DialogInterface dialog, int id) {
                        //User clicks Ok
   //                 }
  //              })
    //            .B(R.string.no, new DialogInterface.OnClickListener() {
    //                public void onClick(DialogInterface dialog, int id) {
                        //User clicks No Thanks
    //                }
    //            })
    //            .create();
  //  }
//}

