package com.zybooks.project2_inventoryapplication;

import android.view.View;

import java.util.ArrayList;

public class Sum_Of_List {

}
