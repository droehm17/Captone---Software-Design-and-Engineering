package com.zybooks.project2_inventoryapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class ListDataActivity extends AppCompatActivity {
    //Initialize Variables
    private static final String TAG = "ListDataActivity";
    InventoryDatabase inventoryDatabase;
    private ListView listView;
    private ToDoList ToDoList;
    private EditText ItemEditText;
    private TextView ItemListTextView;
    private TextView totalsTextView;

    //Create List
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view_layout);

        //Initalize variables
        ItemEditText = findViewById(R.id.toDoItem);
        ItemListTextView = findViewById(R.id.itemList);
        totalsTextView = findViewById(R.id.totalsTextView);
        ToDoList = new ToDoList(this);

    }
    //Resume List
    @Override
    protected void onResume() {
        super.onResume();

        try {
            // Attempt to load list
            ToDoList.readFromFile();
            displayList();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    //Pause List
    @Override
    protected void onPause() {
        super.onPause();

        try {
            // Save list for later
            ToDoList.saveToFile();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    //Add item to list
    public void addButtonClick(View view) {

        // Ignore any leading or trailing spaces
        String item = ItemEditText.getText().toString().trim();

        // Clear the EditText so it's ready for another item
        ItemEditText.setText("");

        // Add the item to the list and display it
        if (item.length() > 0) {
            ToDoList.addItem(item);
            displayList();
            Toast.makeText(this, "Item Added Successfully", Toast.LENGTH_SHORT).show();
        }
    }
    // Display a numbered list of items
    private void displayList() {


        StringBuffer itemText = new StringBuffer();
        String[] items = ToDoList.getItems();
        for (int i = 0; i < items.length; i++) {
            itemText.append((i + 1) + ". " + items[i] + "\n");
        }

        ItemListTextView.setText(itemText);
    }

    //Clear all items from list
    public void clearButtonClick(View view) {
        ToDoList.clear();
        displayList();
    }

    // Remove Item from list if text matches existing item
    public void removeButtonClick(View view) {
        String itemToRemove = ItemEditText.getText().toString();
        if (ToDoList.removeItem(itemToRemove)) {
            displayList();//Display list with removed item
        } else {
            //Text entered does not exist in list
            Toast.makeText(this, "Item Not Found", Toast.LENGTH_SHORT).show();
        }
    }


    // Calculate and Display sum of items added when Total button is clicked
    public void sumOfItemsButtonClick(View view) {
        String[] items = ToDoList.getItems();
        //Create HashMap to store items
        HashMap<String, Integer> words = new HashMap<String, Integer>();
        //Store item entered and how many times it was entered
        for (int i = 0; i < items.length; i++) {
            if (words.containsKey(items[i])) {
                words.put(items[i], words.get(items[i]) + 1);
            }
            else {
                words.put(items[i], 1);
            }
        }
        //Create string to store item entered and occurences of each item
        String result="";
        for (String word : words.keySet()) {
            result += word + ": " + words.get(word) + "\n";
        }
        //Display items entered and occurences of each in TextView
        totalsTextView.setText(result);

    }
}


