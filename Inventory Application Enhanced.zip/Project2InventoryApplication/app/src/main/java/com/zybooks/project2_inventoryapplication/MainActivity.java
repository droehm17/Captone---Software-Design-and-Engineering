package com.zybooks.project2_inventoryapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.opengl.GLDebugHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
        //Initialize variables
        Button signin;
        Button signup;
        Button sms;
        EditText username, password;
        DBHelper DB;
        Button btn_remove;
        EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize Login Attributes
        username = (EditText) findViewById(R.id.editTextTextPersonName2);
        password = (EditText) findViewById(R.id.editTextTextPersonName);
        signin = (Button) findViewById(R.id.loginpagebutton);
        signup = (Button) findViewById(R.id.buttonCreateAccount);
        sms = (Button) findViewById(R.id.buttonSMS);
        DB = new DBHelper(this);




        //----------------------------------Begin Login Functionality-----------------------//
        //Create Account on click listener
        signup.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View v) {
                                          String user = username.getText().toString();
                                          String pass = password.getText().toString();
                                          if (user.equals("") || pass.equals(""))
                                              Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                                          else {
                                              //if(checkuser==false){
                                              Boolean insert = DB.insertData(user, pass);
                                              if (insert == true) {
                                                  Toast.makeText(MainActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                                  Intent intent = new Intent(getApplicationContext(), LogMeIn.class);
                                                  startActivity(intent);
                                              } else {
                                                  Toast.makeText(MainActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                                              }
                                          }
                                      }
                                  }
        );
        //Sign-in on click listener
        signin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Login Button Clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), LogMeIn.class);
                startActivity(intent);
            }

        });
        //SMS Notificaiton ON Click Listener
                sms.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(MainActivity.this, "Send SMS Notifications clicked", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), send_sms.class);
                        startActivity(intent);
                    }

                }
        );




    }
}